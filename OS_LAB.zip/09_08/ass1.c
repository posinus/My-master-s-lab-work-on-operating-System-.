#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	pid_t p;
	p = fork();
	if (p==0) {
		system("ps");
	}
	else wait(0);
	
	printf("COMPLETED\n");
	return 0;
}
