#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	char* buff1[100];
	int fd = open("sample.txt", O_CREAT|O_RDWR, 0777);
	printf("Enter file contents\n");
	int sz = read(0, buff1, 100);
	lseek(fd, 0, SEEK_END);
	write(fd, buff1, sz);

	pid_t p = fork();
	
	if (p==0) {
		char* buff2[100];
		lseek(fd, 0, SEEK_SET);
		int sz1 = read(fd, buff2, 100);
		printf("Size of file is: %d\n", sz1);
	}
	else {
		wait(0);
		close(fd);
	}
	return 0;
}
