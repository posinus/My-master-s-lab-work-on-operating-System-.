#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
//#include <sys/wait.h>

int main() {
	pid_t p;
	int a;
	printf("Before Fork\n");
	p = fork();
	
	if (p==0) {
		scanf("%d", &a);
		printf("I am in child process PID no %d\n", getpid());
		printf("My Parent is %d\n", getppid());
		printf("A = %d\n", a);
	} else {
		wait();
		printf("My Child Process is %d\n", p);
		printf("I am in Parent Process %d\n", getpid());
	}
	
	printf("Common");
	return 0;
}
