#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	int x, y;
	printf("Enter two numbers\n");
	scanf("%d", &x);
	scanf("%d", &y);
	
	pid_t p;
	p = fork();
	if (p==0) {
		printf("MAX No. = %d\n", x>y ? x : y);
	}
	else {
		wait(0);
		printf("SUM = %d\n", x+y);
	}
	return 0;
}
