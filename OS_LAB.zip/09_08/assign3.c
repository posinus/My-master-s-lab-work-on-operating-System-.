#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
int main() {
	char buff1[100], word[20];
	int fd = open("file.txt", O_CREAT|O_RDWR, 0777);
	printf("Enter file contents\n");
	int sz = read(0, buff1, 100);
	lseek(fd, 0, SEEK_END);
	write(fd, buff1, sz);
	printf("Enter word to find in file\n");
	scanf("%s", &word);
	pid_t p = fork();
	if (p==0) {
		int cnt = 0,i = 0,j=-1;
		char buff2[1000], c[1000];
		char *z = NULL;
		lseek(fd, 0, SEEK_SET);
		int sz1 = read(fd, buff2, 1000);
		while(i < sz1) {
			if((buff2[i]>='A' && buff2[i]<='Z')||(buff2[i]>='a' && buff2[i]<='z')){
				c[++j]=buff2[i];}
			else c[++j] = ' ';
			i++;
		}
	   z = strtok(c," ");
	   while(z!=NULL){
	   	if(strcmp(z,word)==0) cnt++;
	   	z = strtok(NULL," ");
	   }
	   printf("%d\n",cnt);
	   }
	else {
		wait(0);
		close(fd);
	}
	return 0;
}
