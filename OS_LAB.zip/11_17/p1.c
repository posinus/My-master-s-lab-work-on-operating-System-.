#include <stdio.h>
#include <omp.h>

int x=5;

first() {
	#pragma omp critical
	x--;
	printf("%d FROM FIRST\n", x);
}

second() {
	#pragma omp critical
	x++;
	printf("%d FROM SECOND\n", x);
}

main() {
	#pragma omp parallel sections
	{
		#pragma omp section
		first();
		#pragma omp section
		second();
	}
	printf("%d LAST VALUE\n", x);
}
