#include <stdio.h>
#include <omp.h>

int x=5;

read() {
	printf("READING %d\n", x);
}

write() {
	#pragma omp critical
	x++;
	printf("WRITING %d\n", x);
}

main() {
	#pragma omp parallel sections
	{
		#pragma omp section
		read();
		#pragma omp section
		write();
	}
}
