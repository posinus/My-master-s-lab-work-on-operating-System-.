#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	char *args[] = {"Hello,", "World!", NULL};
	execv("./myecho", args);
	return 0;
}
