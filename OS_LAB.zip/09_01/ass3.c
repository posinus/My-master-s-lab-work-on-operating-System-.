#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	char* args[] = {NULL};
	execv("./createfile", args);
	return 0;
}
