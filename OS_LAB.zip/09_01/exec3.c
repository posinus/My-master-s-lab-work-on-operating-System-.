#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	char* args[] = {NULL};
	execv("ps", args);
	return 0;
}
