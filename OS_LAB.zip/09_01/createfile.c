#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <fcntl.h>

int main() {
	char* buffer[100];
	int fd = open("file.txt", O_CREAT|O_WRONLY, 0777);
	int sz = read(0, buffer, 100);
	write(fd, buffer, sz);
	close(fd);
	return 0;
}
