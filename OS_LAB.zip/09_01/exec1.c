#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	printf("PID of exec1.c = %d\n", getpid());
	char *args[] = {"Hello", "Students", "Good Afternoon", NULL};
	execv("./exec2", args);
	printf("Back to exec1.c\n");
	return 0;
}
