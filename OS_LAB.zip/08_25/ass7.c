#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

int main() {
int f = open("read.txt", O_RDONLY);
int f2 = open("vov.txt", O_CREAT | O_WRONLY, 0777);
char arr[100];
int sz = read(f, arr, 100);
int i = 0;
while (i < sz) {
if(arr[i] == 'A' || arr[i] == 'a' || arr[i] == 'E' || arr[i] == 'e' || arr[i] == 'I' || arr[i] == 'i'
    || arr[i] == 'O' || arr[i] == 'o' || arr[i] == 'U' || arr[i] == 'u'){
arr[i] = '*';
}
i++;
}
write(f2, arr, sz);
return 0;
}
