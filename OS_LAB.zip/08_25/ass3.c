#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
int main()
{
int fd,fd1;
fd=open("file.txt",O_RDONLY);
fd1=open("file1.txt",O_RDONLY);
int a=lseek(fd,0,SEEK_END);
int b=lseek(fd1,0,SEEK_END);
if(a==b)
printf("The size of the file is same");
else
printf("The size of the file not same");
return 0;
}
