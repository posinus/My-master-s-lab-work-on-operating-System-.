#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
int main()
{
int fd,fd1;
char buff[100];
fd=creat("file1.txt",0777);
fd=open("file.txt",O_RDONLY);
fd1=open("file1.txt",O_WRONLY);
read(fd,buff,20);
write(fd1,buff,20);
return 0;
}

