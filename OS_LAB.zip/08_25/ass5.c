#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

int main() {
int f, l;
char c[20];
f = open("read.txt", O_RDONLY);
printf("Enter location to read from\n");
scanf("%d", &l);
lseek(f, l, SEEK_SET);
int r = read(f, c, 20);
write(0, c, r);
return 0;
}
