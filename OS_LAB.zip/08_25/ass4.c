#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
int main()
{
int fd;
char buffer[100];
fd=open("file1.txt",O_RDONLY);
read(fd,buffer,50);
write(1,buffer,50);
return 0;
}

