#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
int main()
{
int fd;
char buffer[100];
fd=creat("file.txt",0777);
fd=open("file.txt",O_RDWR);
read(0,buffer,20);
write(fd,buffer,20);
return 0;
}
