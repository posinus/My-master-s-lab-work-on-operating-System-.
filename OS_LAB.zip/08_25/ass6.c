#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

int main() {
int f = open("read.txt", O_RDONLY);
int f2 = open("read1.txt", O_CREAT | O_WRONLY, 0777);
char arr[100];
char* a = (char*)calloc(100, sizeof(char));
int sz = read(f, arr, 100);
int i = 0, k = 0;
while (i < sz) {
if((arr[i] >= 'A' && arr[i] <= 'Z') || (arr[i] >= 'a' && arr[i] <= 'z')){
a[k++] = arr[i];
}
i++;
}
write(f2, a, sz);
return 0;
}
