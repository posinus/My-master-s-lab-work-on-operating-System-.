#include <stdio.h>
#include <omp.h>

main() {
	#pragma omp parallel sections
	{
		#pragma omp section
			printf("FIRST %d\n", omp_get_thread_num());
		#pragma omp section
			printf("SECOND %d\n", omp_get_thread_num());	
		#pragma omp section
			printf("THIRD %d\n", omp_get_thread_num());	
	}
}
