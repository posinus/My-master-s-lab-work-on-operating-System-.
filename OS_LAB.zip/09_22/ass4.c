#include <stdio.h>
#include <omp.h>

main() {
	int a[3][3] = {1,2,3,4,5,1,2,3,4};
	int det=0, i, j;
	
	for(i=0; i<3; i++) {
		int prod = 1;
		int anti = 1;
		
		#pragma omp parallel for reduction(*:prod)
		for(j=0; j<3; j++) {
			prod = a[j][(i+j)%3];
		}
		
		#pragma omp parallel for reduction(*:anti)
		for(j=0; j<3; j++) {
			anti = a[j][(i-j+3)%3];
		}
		
		det += prod - anti;
	}
	
	printf("DETERMINANT : %d\n", det);
}
