#include <stdio.h>
#include <omp.h>

main() {
	int a[3] = {1,2,3};
	int b[3] = {2,1,2};
	int dp=0, cp[3];
	int i,j,k;
	
	#pragma omp parallel for reduction(+:dp)
	for(i=0; i<3; i++) dp = a[i] * b[i];
	printf("DOT PRODUCT : %d\n", dp);
	
	#pragma omp parallel sections
	{
		#pragma omp section
		cp[0] = a[1]*b[2] - a[2]*b[1];
		#pragma omp section
		cp[1] = -1 * (a[0]*b[2] - a[2]*b[0]);
		#pragma omp section
		cp[2] = a[0]*b[1] - a[1]*b[0];
	}
	printf("CROSS PRODUCT : %d %d %d\n", cp[0], cp[1], cp[2]); 
	
}
