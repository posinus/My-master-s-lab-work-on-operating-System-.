#include <stdio.h>
#include <omp.h>

main() {
	int i, j, k, c[2][2];
	int a[2][2] = {1,2,3,4};
	int b[2][2] = {1,0,0,1}; 
	
	for(i=0; i<2; i++) {
		#pragma omp parallel for private(k)
		for(k=0; k<2; k++) c[i][k] = 0;
		
		for(j=0; j<2; j++) { 
			#pragma omp parallel for private(k)
			for(k=0; k<2; k++)
				c[i][k] += a[i][j] * b[j][k];
		}
	}
	//PRINT
	for(i=0; i<2; i++) {
		for(j=0; j<2; j++)
			printf("%d ", c[i][j]);
		printf("\n");
	}

}
