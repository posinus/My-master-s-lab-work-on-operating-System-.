#include <stdio.h>
#include <omp.h>

main() {
	int i, m, n, sum=0;
	printf("Enter the Limit : ");
	scanf("%d", &n);
	
	omp_set_dynamic(0);
	m = omp_get_num_procs();
	omp_set_num_threads(m);
	
	#pragma omp parallel for private(i)
	for(i=1; i<n+1; i++) 
		sum += i * (i+1);
		
	printf("%d\n", sum);
}
