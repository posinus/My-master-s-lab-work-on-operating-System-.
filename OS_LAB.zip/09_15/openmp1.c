#include <stdio.h>
#include <omp.h>

main() {
	int m, k;
	m = omp_get_num_procs();
	k = omp_get_max_threads();
	printf("no. of processors available for openmp = %d\n", m);
	printf("max no. of threads = %d\n", k);
}
