#include <stdio.h>
#include <omp.h>

main() {
	int m, k;
	omp_set_dynamic(0);
	//omp_set_num_threads(6);
	
	//#pragma omp parallel
	#pragma omp parallel num_threads(6)
	printf("Hello %d of %d\n", omp_get_thread_num(), omp_get_num_threads());
}
